# FasalDoctor — AI se Fasal Bachayein 🌾

An AI-powered crop disease detection app for farmers and students. Take or upload
a photo of a crop leaf, get an AI-based disease guess with organic/chemical
treatment guidance in Hindi/Hinglish, and hear it read aloud.

> **Honesty note:** This is a complete, runnable Flutter + Firebase app
> architecture with a working `MockDiseaseDetectionProvider` so you can run
> and demo the whole flow **today, with zero AI account setup**. Real
> disease-detection accuracy depends entirely on which AI model/endpoint you
> plug in later (see step 16) — no generic AI model can safely diagnose every
> crop disease out of the box, which is why the architecture is built to swap
> providers without touching UI code.

---

## 1. Features

- 📷 Camera / Gallery capture with validation (format, size, corrupt files)
- 🤖 Pluggable AI architecture: `MockDiseaseDetectionProvider` (works offline,
  no config) and `HuggingFaceDiseaseDetectionProvider` (real inference)
- 🩺 Result screen: disease, confidence, severity, organic + chemical
  guidance, prevention tips, and a mandatory expert-consultation disclaimer
- 🔊 Hindi text-to-speech read-aloud of every result
- ☁️ Firebase Auth (anonymous by default), Firestore scan history, Storage
  for images
- 🌦️ Free weather widget (Open-Meteo — no API key needed), manual city
  fallback if location is denied
- 🌐 Hindi / English / Hinglish language setting
- 📴 Offline-aware: connectivity checks, retry buttons, friendly error copy
- ✅ Unit tests for the model layer and the mock AI provider

## 2. Architecture

```
lib/
  main.dart                     # App entrypoint, Firebase + dotenv init
  core/
    constants/                  # App-wide constants, Firestore/Storage paths
    theme/                      # Material 3 green/white theme
    router/                     # go_router route table
    errors/                     # AppException hierarchy (user-friendly copy)
  models/                       # ScanResult, Scan, WeatherInfo, UserProfile
  services/
    ai_service.dart             # DiseaseDetectionProvider + Mock/HF impls
    firebase_service.dart       # Auth + Firestore
    storage_service.dart        # Firebase Storage uploads
    weather_service.dart        # Open-Meteo client
    voice_service.dart          # flutter_tts wrapper
    network_service.dart        # connectivity checks
  providers/                    # Riverpod state (auth, scan, weather, settings)
  features/                     # One folder per screen (splash, home, camera,
                                 # scanning, result, history, profile, settings)
  widgets/                      # Reusable UI (buttons, cards, error/loading views)
firebase/
  firestore.rules               # Per-user read/write isolation
  storage.rules                 # Per-user image isolation, 12MB/image-only
  firestore.indexes.json
test/                           # Unit tests
```

**AI provider swap pattern** (`lib/services/ai_service.dart`):

```dart
abstract class DiseaseDetectionProvider {
  Future<ScanResult> detectDisease({required File image, ...});
}
```

`CropDiseaseService.auto()` picks `MockDiseaseDetectionProvider` when
`AI_API_URL`/`AI_API_KEY` are empty, and `HuggingFaceDiseaseDetectionProvider`
otherwise — no other code changes needed. Later you can add a
`TFLiteDiseaseDetectionProvider` the same way.

## 3. Requirements

- Flutter SDK 3.22+ (Dart 3.3+) — https://docs.flutter.dev/get-started/install
- An Android device/emulator (this project is Android-first; iOS works too
  with minor Xcode-side config not included here)
- A Firebase project (free Spark plan is enough)
- (Optional) A Hugging Face account for real AI inference

## 4. First-time setup

```bash
# 1. Scaffold native platform folders (android/, ios/ etc. — this repo only
#    ships the Dart source + a manifest override, since native folders are
#    huge and Flutter generates them for you):
flutter create --platforms=android .

# 2. Install dependencies
flutter pub get

# 3. Copy environment template
cp .env.example .env
```

The generated `android/app/src/main/AndroidManifest.xml` will be replaced by
`flutter create`; copy the permissions block from this repo's
`android/app/src/main/AndroidManifest.xml` back into it (camera, location,
internet permissions + the `<queries>` block for image_picker).

## 5. Firebase project setup

1. Go to https://console.firebase.google.com → **Add project**.
2. Inside the project, click **Add app → Android**, package name e.g.
   `com.yourname.fasaldoctor` (must match `android/app/build.gradle`).
3. Download `google-services.json` → place it at `android/app/google-services.json`.
4. In `android/build.gradle` (project-level) add the Google services classpath,
   and in `android/app/build.gradle` (module-level) apply the
   `com.google.gms.google-services` plugin — the standard FlutterFire steps at
   https://firebase.google.com/docs/flutter/setup cover this in 2 minutes, or
   simply run:
   ```bash
   dart pub global activate flutterfire_cli
   flutterfire configure
   ```
   which does steps 2–4 automatically and also generates `firebase_options.dart`
   (if you use that, wire it into `Firebase.initializeApp(options: ...)` in
   `main.dart`).
5. In the Firebase console, enable:
   - **Authentication** → Sign-in method → Anonymous (turn ON). Email/Password
     optional (turn ON if you want the profile screen's email flow).
   - **Firestore Database** → Create database → production mode.
   - **Storage** → Get started.
6. Deploy the security rules shipped in this repo:
   ```bash
   npm install -g firebase-tools
   firebase login
   firebase init firestore storage   # point at the existing firebase/*.rules files
   firebase deploy --only firestore:rules,storage:rules,firestore:indexes
   ```

## 6. AI API setup (optional — app works without this)

If you skip this section, the app automatically uses
`MockDiseaseDetectionProvider` and is fully demoable.

To use real inference:
1. Create a free account at https://huggingface.co.
2. Pick or fine-tune a plant-disease image-classification model (e.g. search
   "plant disease" on the Hugging Face model hub).
3. Get an inference API token: Settings → Access Tokens.
4. In `.env`:
   ```
   AI_API_URL=https://api-inference.huggingface.co/models/<model-id>
   AI_API_KEY=hf_xxxxxxxxxxxxxxxxxxxxx
   ```
5. Because label taxonomies differ per model, adapt
   `HuggingFaceDiseaseDetectionProvider._mapRawResponse()` in
   `lib/services/ai_service.dart` to map the model's raw labels to
   crop/disease/solution text.

**Never commit your real `.env`** — it's already covered by `.gitignore`
(add one if you don't have it: `.env`, `google-services.json`,
`android/key.properties`).

## 7. Weather API setup

Nothing to configure — Open-Meteo (`https://api.open-meteo.com`) is free and
keyless. `WEATHER_API_URL` in `.env` is there only if you want to swap
providers later.

## 8. Running locally

```bash
flutter pub get
flutter run
```

On first launch the app signs the user in anonymously (Firebase Auth), shows
the splash screen, then Home. Tap Camera/Gallery → pick a leaf photo → Use
This Photo → watch the AI Processing screen → see the result → optionally
save to history.

## 9. Building an APK

```bash
flutter build apk --release
# output: build/app/outputs/flutter-apk/app-release.apk
```

## 10. Testing

```bash
flutter test
```

Covers `ScanResult` JSON parsing/low-confidence handling and
`MockDiseaseDetectionProvider` output shape. Add more under `test/` for
weather parsing, auth state, and widget tests as the app grows.

## 11. Replacing the mock AI with real AI later

1. Fill in `AI_API_URL` / `AI_API_KEY` in `.env` (see section 6).
2. `CropDiseaseService.auto()` will automatically switch to
   `HuggingFaceDiseaseDetectionProvider` — no UI/screen code changes needed.
3. To use an on-device TensorFlow Lite model instead of a hosted API, add a
   `TFLiteDiseaseDetectionProvider implements DiseaseDetectionProvider` in
   `ai_service.dart` using the `tflite_flutter` package, and select it in
   `CropDiseaseService.auto()`.

## 12. Security rules summary

- **Firestore**: a user can only read/write `users/{their-own-uid}` and its
  `scans` subcollection. Everything else is denied by default.
- **Storage**: a user can only read/write
  `users/{their-own-uid}/scans/{scanId}/*`, images only, capped at 12MB.

## 13. Troubleshooting

| Problem | Fix |
|---|---|
| App crashes on launch with a Firebase error | Confirm `google-services.json` is in `android/app/` and the Gradle plugin is applied |
| Camera/Gallery does nothing | Check the permission was granted in device Settings → Apps → FasalDoctor |
| Weather card shows an error | Check internet; Open-Meteo has no key but does need connectivity |
| AI always returns the mock samples | `.env` `AI_API_URL`/`AI_API_KEY` are empty — this is expected until you complete section 6 |
| Hindi voice doesn't speak | Device has no Hindi TTS voice installed; app falls back to English automatically |

---

## SETUP CHECKLIST

1. Install Flutter SDK (3.22+) and run `flutter doctor`
2. `flutter create --platforms=android .` inside this project folder
3. `flutter pub get`
4. Create a Firebase project (console.firebase.google.com)
5. Run `flutterfire configure` (or manually add `google-services.json`)
6. Enable Firebase Authentication → Anonymous
7. Enable Cloud Firestore (production mode)
8. Enable Firebase Storage
9. Deploy `firebase/firestore.rules` and `firebase/storage.rules`
10. `cp .env.example .env` (optionally fill in `AI_API_URL` / `AI_API_KEY`)
11. Restore the camera/location/internet permissions in
    `android/app/src/main/AndroidManifest.xml` from this repo's copy
12. `flutter test`
13. `flutter run`
14. `flutter build apk --release` when ready to share an APK
