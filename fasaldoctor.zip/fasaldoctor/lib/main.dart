import 'package:flutter/material.dart';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:firebase_core/firebase_core.dart';
import 'core/router/app_router.dart';
import 'core/theme/app_theme.dart';

Future<void> main() async {
  WidgetsFlutterBinding.ensureInitialized();

  // Load .env — if missing, dotenv just yields empty values and the app
  // falls back to MockDiseaseDetectionProvider automatically (see ai_service.dart).
  try {
    await dotenv.load(fileName: '.env');
  } catch (_) {
    // No .env file present — fine for a fresh checkout during dev.
  }

  try {
    await Firebase.initializeApp();
  } catch (e) {
    // App still boots without Firebase during early local dev / CI screenshots,
    // but auth/history features will show FirebaseUnavailableException messages.
    // ignore: avoid_print
    print('Firebase init failed: $e');
  }

  runApp(const ProviderScope(child: FasalDoctorApp()));
}

class FasalDoctorApp extends StatelessWidget {
  const FasalDoctorApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp.router(
      title: 'FasalDoctor',
      debugShowCheckedModeBanner: false,
      theme: AppTheme.light(),
      routerConfig: appRouter,
    );
  }
}
