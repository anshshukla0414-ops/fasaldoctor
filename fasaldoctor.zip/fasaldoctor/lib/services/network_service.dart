import 'package:connectivity_plus/connectivity_plus.dart';

/// Wraps connectivity checks so the rest of the app never talks to
/// connectivity_plus directly.
class NetworkService {
  final Connectivity _connectivity = Connectivity();

  Future<bool> hasInternet() async {
    final result = await _connectivity.checkConnectivity();
    return !result.contains(ConnectivityResult.none);
  }

  Stream<bool> onConnectivityChanged() {
    return _connectivity.onConnectivityChanged.map(
      (results) => !results.contains(ConnectivityResult.none),
    );
  }
}
