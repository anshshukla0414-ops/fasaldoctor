import 'dart:convert';
import 'dart:io';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import '../core/errors/app_exceptions.dart';
import '../models/scan_result.dart';

/// ============================================================
/// AI PROVIDER ARCHITECTURE
/// ------------------------------------------------------------
/// DiseaseDetectionProvider is the contract every AI backend must
/// implement. This lets us swap Mock -> HuggingFace -> a future
/// TensorFlow Lite / ONNX / custom model provider WITHOUT touching
/// any UI code.
/// ============================================================
abstract class DiseaseDetectionProvider {
  Future<ScanResult> detectDisease({
    required File image,
    String? cropType,
    String? location,
    String language = 'hi',
  });
}

/// Works with zero configuration. Used automatically whenever
/// AI_API_URL / AI_API_KEY are missing, so the app is fully runnable
/// in development without any external AI account.
class MockDiseaseDetectionProvider implements DiseaseDetectionProvider {
  @override
  Future<ScanResult> detectDisease({
    required File image,
    String? cropType,
    String? location,
    String language = 'hi',
  }) async {
    // Simulate network + inference latency for a realistic UX during dev.
    await Future.delayed(const Duration(seconds: 2));

    // Deterministic-ish "random" pick based on file size, so repeated
    // demos with the same image behave consistently.
    final len = await image.length();
    final samples = _mockSamples(cropType);
    final result = samples[len % samples.length];

    // ignore: avoid_print
    print('[DEV] MockDiseaseDetectionProvider used — not a real AI diagnosis.');
    return result;
  }

  List<ScanResult> _mockSamples(String? crop) {
    final resolvedCrop = crop ?? 'Cotton';
    return [
      ScanResult(
        success: true,
        crop: resolvedCrop,
        disease: 'Leaf Spot',
        confidence: 0.91,
        severity: 'medium',
        description:
            'Patti par gol, bhoore/kaale daag dikh rahe hain — yeh aksar fungal infection ki wajah se hota hai.',
        organicSolution: const [
          'Affected pattiyon ko turant hata dein',
          'Khet mein sahi jal-nikasi (drainage) rakhein',
          'Neem-oil based spray ka upyog karein',
        ],
        chemicalSolution: const [
          'Local Krishi Vigyan Kendra (KVK) se fungicide ki sahi dose confirm karein',
        ],
        prevention: const [
          'Crop rotation apnayein',
          'Zyada paani dene se bachein',
          'Achhi quality ke certified beej use karein',
        ],
        warning:
            'AI result sirf informational guidance hai. Severe crop damage ya chemical treatment ke liye local agriculture expert/KVK se salah lein.',
        language: 'hi',
      ),
      ScanResult(
        success: true,
        crop: resolvedCrop,
        disease: 'Powdery Mildew',
        confidence: 0.87,
        severity: 'low',
        description: 'Patti ki satah par safed powder jaisi parat dikh rahi hai.',
        organicSolution: const [
          'Doodh aur paani ka 1:9 ghol spray karein',
          'Affected leaves ko alag karein',
          'Achhi dhoop aur hawa ka circulation banaye rakhein',
        ],
        chemicalSolution: const [
          'Sulphur-based fungicide ke liye KVK/expert se sampark karein',
        ],
        prevention: const [
          'Paudhon ke beech uchit doori rakhein',
          'Overhead watering se bachein',
        ],
        warning:
            'AI result sirf informational guidance hai. Severe crop damage ya chemical treatment ke liye local agriculture expert/KVK se salah lein.',
        language: 'hi',
      ),
      ScanResult.lowConfidenceFallback(),
    ];
  }
}

/// Real inference via a configurable Hugging Face (or any compatible)
/// image-classification endpoint. URL/key come only from environment
/// variables — never hardcoded.
class HuggingFaceDiseaseDetectionProvider implements DiseaseDetectionProvider {
  final http.Client _client;
  HuggingFaceDiseaseDetectionProvider({http.Client? client})
      : _client = client ?? http.Client();

  String get _apiUrl => dotenv.env['AI_API_URL'] ?? '';
  String get _apiKey => dotenv.env['AI_API_KEY'] ?? '';

  @override
  Future<ScanResult> detectDisease({
    required File image,
    String? cropType,
    String? location,
    String language = 'hi',
  }) async {
    if (_apiUrl.isEmpty) {
      throw AIServiceUnavailableException();
    }

    try {
      final bytes = await image.readAsBytes();
      final response = await _client
          .post(
            Uri.parse(_apiUrl),
            headers: {
              'Authorization': 'Bearer $_apiKey',
              'Content-Type': 'application/octet-stream',
            },
            body: bytes,
          )
          .timeout(const Duration(seconds: 20));

      if (response.statusCode != 200) {
        throw AIServiceUnavailableException();
      }

      final decoded = jsonDecode(response.body);
      // NOTE: Real Hugging Face classification models return a list like
      // [{"label": "...", "score": 0.9}, ...]. Because label taxonomies
      // vary per model, mapping raw labels -> crop/disease/solutions
      // should be adapted here once a specific model is chosen.
      final mapped = _mapRawResponse(decoded, cropType, language);
      if (mapped.confidence < 0.5) {
        return ScanResult.lowConfidenceFallback();
      }
      return mapped;
    } on AppException {
      rethrow;
    } catch (_) {
      throw AITimeoutException();
    }
  }

  ScanResult _mapRawResponse(dynamic decoded, String? cropType, String language) {
    // Placeholder mapping — replace with real label->disease mapping
    // once a specific crop-disease model is selected.
    double confidence = 0.0;
    String label = 'Unknown';
    if (decoded is List && decoded.isNotEmpty) {
      final top = decoded.first as Map<String, dynamic>;
      confidence = (top['score'] as num?)?.toDouble() ?? 0.0;
      label = top['label'] as String? ?? 'Unknown';
    }
    return ScanResult(
      success: true,
      crop: cropType ?? 'Unknown',
      disease: label,
      confidence: confidence,
      severity: confidence > 0.8 ? 'medium' : 'low',
      description: 'Model ke output ke aadhar par prathmik anuman.',
      organicSolution: const ['Local KVK/expert se organic upchar confirm karein'],
      chemicalSolution: const ['Local KVK/expert se dosage confirm karein'],
      prevention: const ['Crop rotation', 'Sahi sinchai', 'Certified beej ka upyog'],
      warning:
          'AI result sirf informational guidance hai. Severe crop damage ya chemical treatment ke liye local agriculture expert/KVK se salah lein.',
      language: language,
    );
  }
}

/// Facade used by the rest of the app. Picks the right provider
/// automatically based on whether AI credentials are configured.
class CropDiseaseService {
  final DiseaseDetectionProvider _provider;

  CropDiseaseService._(this._provider);

  factory CropDiseaseService.auto() {
    final apiUrl = dotenv.env['AI_API_URL'] ?? '';
    final apiKey = dotenv.env['AI_API_KEY'] ?? '';
    if (apiUrl.isEmpty || apiKey.isEmpty) {
      // ignore: avoid_print
      print('[DEV] AI credentials missing — using MockDiseaseDetectionProvider.');
      return CropDiseaseService._(MockDiseaseDetectionProvider());
    }
    return CropDiseaseService._(HuggingFaceDiseaseDetectionProvider());
  }

  factory CropDiseaseService.withProvider(DiseaseDetectionProvider provider) =>
      CropDiseaseService._(provider);

  Future<ScanResult> analyze({
    required File image,
    String? cropType,
    String? location,
    String language = 'hi',
  }) {
    return _provider.detectDisease(
      image: image,
      cropType: cropType,
      location: location,
      language: language,
    );
  }
}
