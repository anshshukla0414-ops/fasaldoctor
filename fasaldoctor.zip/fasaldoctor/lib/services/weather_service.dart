import 'dart:convert';
import 'package:flutter_dotenv/flutter_dotenv.dart';
import 'package:http/http.dart' as http;
import '../core/errors/app_exceptions.dart';
import '../models/weather.dart';

/// Uses Open-Meteo (free, no API key required) by default.
class WeatherService {
  final http.Client _client;
  WeatherService({http.Client? client}) : _client = client ?? http.Client();

  String get _baseUrl =>
      dotenv.env['WEATHER_API_URL'] ?? 'https://api.open-meteo.com/v1/forecast';

  Future<WeatherInfo> fetchByCoordinates({
    required double lat,
    required double lon,
    String locationLabel = 'Aapka Sthaan',
  }) async {
    try {
      final uri = Uri.parse(_baseUrl).replace(queryParameters: {
        'latitude': lat.toString(),
        'longitude': lon.toString(),
        'current':
            'temperature_2m,relative_humidity_2m,precipitation_probability,weather_code,wind_speed_10m',
        'timezone': 'auto',
      });
      final response = await _client.get(uri).timeout(const Duration(seconds: 10));
      if (response.statusCode != 200) {
        throw WeatherUnavailableException();
      }
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      return WeatherInfo.fromOpenMeteo(json, locationLabel);
    } on WeatherUnavailableException {
      rethrow;
    } catch (_) {
      throw WeatherUnavailableException();
    }
  }

  /// Geocode a manually-entered city name (used when location permission
  /// is denied). Uses Open-Meteo's free geocoding endpoint.
  Future<({double lat, double lon, String label})> geocodeCity(String city) async {
    try {
      final uri = Uri.parse('https://geocoding-api.open-meteo.com/v1/search')
          .replace(queryParameters: {'name': city, 'count': '1'});
      final response = await _client.get(uri).timeout(const Duration(seconds: 10));
      final json = jsonDecode(response.body) as Map<String, dynamic>;
      final results = json['results'] as List?;
      if (results == null || results.isEmpty) {
        throw WeatherUnavailableException();
      }
      final first = results.first as Map<String, dynamic>;
      return (
        lat: (first['latitude'] as num).toDouble(),
        lon: (first['longitude'] as num).toDouble(),
        label: first['name'] as String? ?? city,
      );
    } catch (_) {
      throw WeatherUnavailableException();
    }
  }
}
