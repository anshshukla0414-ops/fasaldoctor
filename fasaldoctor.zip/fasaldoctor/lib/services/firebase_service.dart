import 'package:cloud_firestore/cloud_firestore.dart';
import 'package:firebase_auth/firebase_auth.dart';
import '../core/constants/app_constants.dart';
import '../core/errors/app_exceptions.dart';
import '../models/scan_result.dart';
import '../models/user_profile.dart';

/// Wraps all direct Firebase Auth + Firestore calls so the rest of the
/// app never imports firebase packages directly.
class FirebaseService {
  final FirebaseAuth _auth;
  final FirebaseFirestore _firestore;

  FirebaseService({FirebaseAuth? auth, FirebaseFirestore? firestore})
      : _auth = auth ?? FirebaseAuth.instance,
        _firestore = firestore ?? FirebaseFirestore.instance;

  User? get currentUser => _auth.currentUser;
  Stream<User?> authStateChanges() => _auth.authStateChanges();

  /// Anonymous sign-in on first launch, per spec section 13.
  Future<User> ensureSignedIn() async {
    try {
      if (_auth.currentUser != null) return _auth.currentUser!;
      final cred = await _auth.signInAnonymously();
      final user = cred.user;
      if (user == null) throw FirebaseUnavailableException();
      await _createUserDocIfMissing(user.uid);
      return user;
    } catch (e) {
      if (e is AppException) rethrow;
      throw FirebaseUnavailableException();
    }
  }

  Future<User> signUpWithEmail(String email, String password) async {
    try {
      final cred = await _auth.createUserWithEmailAndPassword(
        email: email,
        password: password,
      );
      await _createUserDocIfMissing(cred.user!.uid);
      return cred.user!;
    } catch (_) {
      throw FirebaseUnavailableException();
    }
  }

  Future<User> signInWithEmail(String email, String password) async {
    try {
      final cred = await _auth.signInWithEmailAndPassword(
        email: email,
        password: password,
      );
      return cred.user!;
    } catch (_) {
      throw FirebaseUnavailableException();
    }
  }

  Future<void> signOut() => _auth.signOut();

  Future<void> _createUserDocIfMissing(String uid) async {
    final ref = _firestore.doc(FirestorePaths.userDoc(uid));
    final snap = await ref.get();
    if (!snap.exists) {
      final profile = UserProfile(uid: uid, createdAt: DateTime.now());
      await ref.set(profile.toFirestore());
    }
  }

  Future<UserProfile> getUserProfile(String uid) async {
    final snap = await _firestore.doc(FirestorePaths.userDoc(uid)).get();
    if (!snap.exists) {
      return UserProfile(uid: uid, createdAt: DateTime.now());
    }
    return UserProfile.fromFirestore(snap.data()!, uid);
  }

  Future<void> updateUserProfile(UserProfile profile) async {
    await _firestore
        .doc(FirestorePaths.userDoc(profile.uid))
        .set(profile.toFirestore(), SetOptions(merge: true));
  }

  Future<void> saveScan(Scan scan) async {
    try {
      await _firestore
          .doc(FirestorePaths.scanDoc(scan.userId, scan.scanId))
          .set(scan.toFirestore());
    } catch (_) {
      throw FirebaseUnavailableException();
    }
  }

  Stream<List<Scan>> watchScans(String uid) {
    return _firestore
        .collection(FirestorePaths.scansCollection(uid))
        .orderBy('createdAt', descending: true)
        .snapshots()
        .map((snap) =>
            snap.docs.map((d) => Scan.fromFirestore(d.data(), d.id)).toList());
  }

  Future<void> deleteScan(String uid, String scanId) async {
    await _firestore.doc(FirestorePaths.scanDoc(uid, scanId)).delete();
  }
}
