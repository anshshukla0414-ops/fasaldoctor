import 'package:flutter_tts/flutter_tts.dart';

/// Wraps flutter_tts. Falls back gracefully if Hindi isn't available
/// on the device.
class VoiceService {
  final FlutterTts _tts = FlutterTts();
  bool _initialized = false;

  Future<void> _ensureInit() async {
    if (_initialized) return;
    final languages = await _tts.getLanguages;
    final langs = (languages as List).cast<String>();

    if (langs.any((l) => l.toLowerCase().startsWith('hi'))) {
      await _tts.setLanguage('hi-IN');
    } else if (langs.any((l) => l.toLowerCase().startsWith('en'))) {
      await _tts.setLanguage('en-IN');
    }
    await _tts.setSpeechRate(0.45);
    await _tts.setPitch(1.0);
    _initialized = true;
  }

  Future<void> speak(String text) async {
    await _ensureInit();
    await _tts.speak(text);
  }

  Future<void> pause() => _tts.pause();
  Future<void> stop() => _tts.stop();
}
