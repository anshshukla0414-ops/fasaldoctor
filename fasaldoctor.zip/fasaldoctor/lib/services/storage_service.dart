import 'dart:io';
import 'package:firebase_storage/firebase_storage.dart';
import '../core/constants/app_constants.dart';
import '../core/errors/app_exceptions.dart';

/// Uploads scan images to Firebase Storage under a per-user, per-scan path.
class StorageService {
  final FirebaseStorage _storage;
  StorageService({FirebaseStorage? storage})
      : _storage = storage ?? FirebaseStorage.instance;

  Future<String> uploadScanImage({
    required String uid,
    required String scanId,
    required File image,
  }) async {
    try {
      final ref = _storage.ref(StoragePaths.scanImage(uid, scanId));
      final task = await ref.putFile(
        image,
        SettableMetadata(contentType: 'image/jpeg'),
      );
      return await task.ref.getDownloadURL();
    } catch (_) {
      throw FirebaseUnavailableException();
    }
  }

  Future<void> deleteScanImage({required String uid, required String scanId}) async {
    try {
      await _storage.ref(StoragePaths.scanImage(uid, scanId)).delete();
    } catch (_) {
      // Non-fatal: image may already be gone.
    }
  }
}
