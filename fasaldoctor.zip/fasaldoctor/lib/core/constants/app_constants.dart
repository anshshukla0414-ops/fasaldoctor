class AppConstants {
  static const String appName = 'FasalDoctor';
  static const String appTagline = 'AI se Fasal Bachayein';

  static const double lowConfidenceThreshold = 0.5;

  static const List<String> supportedCrops = [
    'Cotton',
    'Wheat',
    'Rice',
    'Tomato',
    'Potato',
    'Maize',
    'Sugarcane',
    'Other',
  ];

  static const List<String> supportedLanguages = ['hi', 'en', 'hinglish'];
}

class FirestorePaths {
  static String userDoc(String uid) => 'users/$uid';
  static String scansCollection(String uid) => 'users/$uid/scans';
  static String scanDoc(String uid, String scanId) => 'users/$uid/scans/$scanId';
}

class StoragePaths {
  static String scanImage(String uid, String scanId) =>
      'users/$uid/scans/$scanId/image.jpg';
}
