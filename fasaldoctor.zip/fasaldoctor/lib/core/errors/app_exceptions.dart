/// User-friendly exceptions. Messages are Hindi/Hinglish so they can be
/// shown directly in the UI without translation.
class AppException implements Exception {
  final String userMessage;
  final Object? cause;
  AppException(this.userMessage, [this.cause]);
  @override
  String toString() => userMessage;
}

class NoInternetException extends AppException {
  NoInternetException()
      : super('Internet connection check karein aur dobara try karein.');
}

class CameraPermissionDeniedException extends AppException {
  CameraPermissionDeniedException()
      : super('Camera permission nahi mili. Settings mein jaakar permission on karein.');
}

class GalleryPermissionDeniedException extends AppException {
  GalleryPermissionDeniedException()
      : super('Gallery permission nahi mili. Settings mein jaakar permission on karein.');
}

class LocationPermissionDeniedException extends AppException {
  LocationPermissionDeniedException()
      : super('Location permission nahi mili. Aap manually shehar select kar sakte hain.');
}

class InvalidImageException extends AppException {
  InvalidImageException()
      : super('Image sahi format mein nahi hai ya corrupt hai. Dusri photo chunein.');
}

class ImageTooLargeException extends AppException {
  ImageTooLargeException()
      : super('Image ka size bahut bada hai. Kripya doosri photo try karein.');
}

class AIServiceUnavailableException extends AppException {
  AIServiceUnavailableException()
      : super('AI service abhi available nahi hai. Thodi der baad try karein.');
}

class AITimeoutException extends AppException {
  AITimeoutException()
      : super('AI response mein zyada samay lag raha hai. Dobara try karein.');
}

class WeatherUnavailableException extends AppException {
  WeatherUnavailableException()
      : super('Mausam ki jaankari abhi uplabdh nahi hai.');
}

class FirebaseUnavailableException extends AppException {
  FirebaseUnavailableException()
      : super('Server se connect nahi ho paya. Kripya baad mein try karein.');
}
