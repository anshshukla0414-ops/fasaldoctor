import 'package:firebase_auth/firebase_auth.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../services/firebase_service.dart';

final firebaseServiceProvider = Provider<FirebaseService>((ref) => FirebaseService());

final authStateProvider = StreamProvider<User?>((ref) {
  return ref.watch(firebaseServiceProvider).authStateChanges();
});

/// Ensures an anonymous user exists as soon as the app starts (spec #13).
final ensureSignedInProvider = FutureProvider<User>((ref) async {
  return ref.watch(firebaseServiceProvider).ensureSignedIn();
});
