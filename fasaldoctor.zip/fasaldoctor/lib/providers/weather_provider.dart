import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:geolocator/geolocator.dart';
import '../core/errors/app_exceptions.dart';
import '../models/weather.dart';
import '../services/weather_service.dart';

final weatherServiceProvider = Provider<WeatherService>((ref) => WeatherService());

class WeatherState {
  final bool loading;
  final WeatherInfo? info;
  final String? errorMessage;
  final bool locationDenied;

  const WeatherState({
    this.loading = false,
    this.info,
    this.errorMessage,
    this.locationDenied = false,
  });

  WeatherState copyWith({
    bool? loading,
    WeatherInfo? info,
    String? errorMessage,
    bool? locationDenied,
  }) {
    return WeatherState(
      loading: loading ?? this.loading,
      info: info ?? this.info,
      errorMessage: errorMessage,
      locationDenied: locationDenied ?? this.locationDenied,
    );
  }
}

class WeatherController extends StateNotifier<WeatherState> {
  final WeatherService _service;
  WeatherController(this._service) : super(const WeatherState());

  Future<void> loadForCurrentLocation() async {
    state = state.copyWith(loading: true, errorMessage: null, locationDenied: false);
    try {
      final permission = await Geolocator.checkPermission();
      var granted = permission == LocationPermission.always ||
          permission == LocationPermission.whileInUse;

      if (!granted) {
        final requested = await Geolocator.requestPermission();
        granted = requested == LocationPermission.always ||
            requested == LocationPermission.whileInUse;
      }

      if (!granted) {
        state = state.copyWith(loading: false, locationDenied: true);
        return;
      }

      final position = await Geolocator.getCurrentPosition();
      final info = await _service.fetchByCoordinates(
        lat: position.latitude,
        lon: position.longitude,
        locationLabel: 'Aapka Sthaan',
      );
      state = state.copyWith(loading: false, info: info);
    } on AppException catch (e) {
      state = state.copyWith(loading: false, errorMessage: e.userMessage);
    } catch (_) {
      state = state.copyWith(loading: false, errorMessage: 'Mausam load nahi ho paya.');
    }
  }

  Future<void> loadForCity(String city) async {
    state = state.copyWith(loading: true, errorMessage: null);
    try {
      final geo = await _service.geocodeCity(city);
      final info = await _service.fetchByCoordinates(
        lat: geo.lat,
        lon: geo.lon,
        locationLabel: geo.label,
      );
      state = state.copyWith(loading: false, info: info);
    } on AppException catch (e) {
      state = state.copyWith(loading: false, errorMessage: e.userMessage);
    }
  }
}

final weatherControllerProvider =
    StateNotifierProvider<WeatherController, WeatherState>((ref) {
  return WeatherController(ref.watch(weatherServiceProvider));
});
