import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:shared_preferences/shared_preferences.dart';

class AppSettings {
  final String language; // 'hi' | 'en' | 'hinglish'
  final bool voiceEnabled;
  final bool notificationsEnabled;

  const AppSettings({
    this.language = 'hi',
    this.voiceEnabled = true,
    this.notificationsEnabled = true,
  });

  AppSettings copyWith({String? language, bool? voiceEnabled, bool? notificationsEnabled}) {
    return AppSettings(
      language: language ?? this.language,
      voiceEnabled: voiceEnabled ?? this.voiceEnabled,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
    );
  }
}

class SettingsController extends StateNotifier<AppSettings> {
  SettingsController() : super(const AppSettings()) {
    _load();
  }

  static const _kLanguage = 'settings_language';
  static const _kVoice = 'settings_voice_enabled';
  static const _kNotif = 'settings_notifications_enabled';

  Future<void> _load() async {
    final prefs = await SharedPreferences.getInstance();
    state = AppSettings(
      language: prefs.getString(_kLanguage) ?? 'hi',
      voiceEnabled: prefs.getBool(_kVoice) ?? true,
      notificationsEnabled: prefs.getBool(_kNotif) ?? true,
    );
  }

  Future<void> setLanguage(String language) async {
    state = state.copyWith(language: language);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setString(_kLanguage, language);
  }

  Future<void> setVoiceEnabled(bool enabled) async {
    state = state.copyWith(voiceEnabled: enabled);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kVoice, enabled);
  }

  Future<void> setNotificationsEnabled(bool enabled) async {
    state = state.copyWith(notificationsEnabled: enabled);
    final prefs = await SharedPreferences.getInstance();
    await prefs.setBool(_kNotif, enabled);
  }

  Future<void> clearLocalCache() async {
    final prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    state = const AppSettings();
  }
}

final settingsProvider = StateNotifierProvider<SettingsController, AppSettings>(
  (ref) => SettingsController(),
);
