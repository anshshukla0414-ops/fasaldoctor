import 'dart:io';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:uuid/uuid.dart';
import '../models/scan_result.dart';
import '../services/ai_service.dart';
import '../services/firebase_service.dart';
import '../services/storage_service.dart';
import 'auth_provider.dart';
import 'settings_provider.dart';

final cropDiseaseServiceProvider =
    Provider<CropDiseaseService>((ref) => CropDiseaseService.auto());

final storageServiceProvider = Provider<StorageService>((ref) => StorageService());

enum ScanStage { idle, uploading, detectingLeaf, analyzing, calculatingConfidence, preparingSolution, done, error }

class ScanState {
  final ScanStage stage;
  final ScanResult? result;
  final String? errorMessage;
  final File? image;

  const ScanState({
    this.stage = ScanStage.idle,
    this.result,
    this.errorMessage,
    this.image,
  });

  ScanState copyWith({
    ScanStage? stage,
    ScanResult? result,
    String? errorMessage,
    File? image,
  }) {
    return ScanState(
      stage: stage ?? this.stage,
      result: result ?? this.result,
      errorMessage: errorMessage,
      image: image ?? this.image,
    );
  }
}

class ScanController extends StateNotifier<ScanState> {
  final CropDiseaseService _aiService;
  final FirebaseService _firebaseService;
  final StorageService _storageService;
  final String? _language;

  ScanController(this._aiService, this._firebaseService, this._storageService, this._language)
      : super(const ScanState());

  Future<void> runScan({required File image, String? cropType}) async {
    state = state.copyWith(stage: ScanStage.uploading, image: image, errorMessage: null);
    try {
      state = state.copyWith(stage: ScanStage.detectingLeaf);
      await Future.delayed(const Duration(milliseconds: 400));

      state = state.copyWith(stage: ScanStage.analyzing);
      final result = await _aiService.analyze(
        image: image,
        cropType: cropType,
        language: _language ?? 'hi',
      );

      state = state.copyWith(stage: ScanStage.calculatingConfidence);
      await Future.delayed(const Duration(milliseconds: 300));

      state = state.copyWith(stage: ScanStage.preparingSolution);
      await Future.delayed(const Duration(milliseconds: 300));

      state = state.copyWith(stage: ScanStage.done, result: result);
    } catch (e) {
      state = state.copyWith(stage: ScanStage.error, errorMessage: e.toString());
    }
  }

  /// Persists the current result (image + metadata) to Firebase.
  Future<void> saveCurrentScan(String uid, {String? location}) async {
    if (state.result == null || state.image == null) return;
    final scanId = const Uuid().v4();
    final imageUrl = await _storageService.uploadScanImage(
      uid: uid,
      scanId: scanId,
      image: state.image!,
    );
    final result = state.result!;
    final scan = Scan(
      scanId: scanId,
      userId: uid,
      imageUrl: imageUrl,
      crop: result.crop,
      disease: result.disease,
      confidence: result.confidence,
      severity: result.severity,
      result: result,
      createdAt: DateTime.now(),
      location: location,
      language: result.language,
    );
    await _firebaseService.saveScan(scan);
  }

  void reset() => state = const ScanState();
}

final scanControllerProvider = StateNotifierProvider<ScanController, ScanState>((ref) {
  final settings = ref.watch(settingsProvider);
  return ScanController(
    ref.watch(cropDiseaseServiceProvider),
    ref.watch(firebaseServiceProvider),
    ref.watch(storageServiceProvider),
    settings.language,
  );
});

final scansHistoryProvider = StreamProvider.family((ref, String uid) {
  return ref.watch(firebaseServiceProvider).watchScans(uid);
});
