import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/router/app_router.dart';
import '../../providers/auth_provider.dart';
import '../../providers/scan_provider.dart';
import '../../providers/settings_provider.dart';
import '../../services/voice_service.dart';
import '../../widgets/disease_card.dart';
import '../../widgets/primary_button.dart';

final voiceServiceProvider = Provider<VoiceService>((ref) => VoiceService());

class ResultScreen extends ConsumerStatefulWidget {
  const ResultScreen({super.key});

  @override
  ConsumerState<ResultScreen> createState() => _ResultScreenState();
}

class _ResultScreenState extends ConsumerState<ResultScreen> {
  bool _saving = false;
  bool _saved = false;

  Future<void> _speak(String text) async {
    final settings = ref.read(settingsProvider);
    if (!settings.voiceEnabled) return;
    await ref.read(voiceServiceProvider).speak(text);
  }

  Future<void> _saveScan() async {
    setState(() => _saving = true);
    try {
      final user = ref.read(firebaseServiceProvider).currentUser;
      if (user != null) {
        await ref.read(scanControllerProvider.notifier).saveCurrentScan(user.uid);
      }
      if (mounted) setState(() { _saved = true; _saving = false; });
    } catch (_) {
      if (mounted) setState(() => _saving = false);
    }
  }

  @override
  Widget build(BuildContext context) {
    final scan = ref.watch(scanControllerProvider);
    final result = scan.result;

    if (result == null) {
      return Scaffold(
        appBar: AppBar(title: const Text('Fasal Ki Jaanch')),
        body: const Center(child: Text('Koi result nahi mila.')),
      );
    }

    final fullReadout = [
      result.disease,
      result.description,
      if (result.organicSolution.isNotEmpty) 'Organic solution: ${result.organicSolution.join(", ")}',
      if (result.chemicalSolution.isNotEmpty) 'Chemical solution: ${result.chemicalSolution.join(", ")}',
      if (result.prevention.isNotEmpty) 'Bachav: ${result.prevention.join(", ")}',
      result.warning,
    ].join('. ');

    return Scaffold(
      appBar: AppBar(
        title: const Text('Fasal Ki Jaanch'),
        actions: [
          IconButton(
            icon: const Icon(Icons.volume_up),
            tooltip: 'Sunne ke liye dabayein',
            onPressed: () => _speak(fullReadout),
          ),
        ],
      ),
      body: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          DiseaseCard(result: result),
          const SizedBox(height: 16),
          if (result.isLowConfidence)
            Card(
              color: Colors.amber.shade50,
              child: Padding(
                padding: const EdgeInsets.all(16),
                child: Text(result.description),
              ),
            )
          else ...[
            _Section(title: 'Kya Hua?', body: result.description),
            _Section(
              title: 'Organic Solution',
              bullets: result.organicSolution,
            ),
            _Section(
              title: 'Chemical Solution',
              bullets: result.chemicalSolution,
              emptyText: 'Reliable model/database information available nahi hai — local expert se salah lein.',
            ),
            _Section(title: 'Kaise Bachayein?', bullets: result.prevention),
          ],
          Card(
            color: Colors.red.shade50,
            child: Padding(
              padding: const EdgeInsets.all(16),
              child: Row(
                children: [
                  const Icon(Icons.warning_amber_rounded, color: Colors.redAccent),
                  const SizedBox(width: 10),
                  Expanded(child: Text(result.warning, style: const TextStyle(fontSize: 13))),
                ],
              ),
            ),
          ),
          const SizedBox(height: 20),
          PrimaryButton(
            label: _saved ? 'Scan Save Ho Gaya' : 'Scan History Mein Save Karein',
            icon: _saved ? Icons.check_circle : Icons.save_outlined,
            onPressed: _saved ? null : _saveScan,
            loading: _saving,
          ),
          const SizedBox(height: 10),
          OutlinedButton(
            onPressed: () {
              ref.read(scanControllerProvider.notifier).reset();
              context.go(AppRoutes.home);
            },
            child: const Text('Naya Scan Karein'),
          ),
        ],
      ),
    );
  }
}

class _Section extends StatelessWidget {
  final String title;
  final String? body;
  final List<String>? bullets;
  final String? emptyText;

  const _Section({required this.title, this.body, this.bullets, this.emptyText});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(title, style: Theme.of(context).textTheme.titleMedium?.copyWith(fontWeight: FontWeight.bold)),
            const SizedBox(height: 8),
            if (body != null) Text(body!),
            if (bullets != null && bullets!.isNotEmpty)
              ...bullets!.map((b) => Padding(
                    padding: const EdgeInsets.only(bottom: 4),
                    child: Row(
                      crossAxisAlignment: CrossAxisAlignment.start,
                      children: [const Text('• '), Expanded(child: Text(b))],
                    ),
                  )),
            if (bullets != null && bullets!.isEmpty && emptyText != null)
              Text(emptyText!, style: const TextStyle(color: Colors.grey)),
          ],
        ),
      ),
    );
  }
}
