import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/router/app_router.dart';
import '../../providers/weather_provider.dart';
import '../../widgets/weather_card.dart';
import '../../widgets/error_view.dart';
import '../history/history_screen.dart';
import '../profile/profile_screen.dart';

class HomeScreen extends ConsumerStatefulWidget {
  const HomeScreen({super.key});

  @override
  ConsumerState<HomeScreen> createState() => _HomeScreenState();
}

class _HomeScreenState extends ConsumerState<HomeScreen> {
  int _tab = 0;

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      ref.read(weatherControllerProvider.notifier).loadForCurrentLocation();
    });
  }

  @override
  Widget build(BuildContext context) {
    final pages = [const _HomeDashboard(), const HistoryScreen(embedded: true), const ProfileScreen(embedded: true)];
    return Scaffold(
      appBar: _tab == 0 ? AppBar(title: const Text('FasalDoctor')) : null,
      body: pages[_tab],
      bottomNavigationBar: BottomNavigationBar(
        currentIndex: _tab,
        onTap: (i) => setState(() => _tab = i),
        items: const [
          BottomNavigationBarItem(icon: Icon(Icons.home_outlined), label: 'Home'),
          BottomNavigationBarItem(icon: Icon(Icons.history), label: 'History'),
          BottomNavigationBarItem(icon: Icon(Icons.person_outline), label: 'Profile'),
        ],
      ),
    );
  }
}

class _HomeDashboard extends ConsumerWidget {
  const _HomeDashboard();

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final weather = ref.watch(weatherControllerProvider);

    return SafeArea(
      child: ListView(
        padding: const EdgeInsets.all(16),
        children: [
          Text('Namaste, Kisan 👋',
              style: Theme.of(context).textTheme.headlineSmall?.copyWith(fontWeight: FontWeight.bold)),
          const SizedBox(height: 16),
          Card(
            color: Theme.of(context).colorScheme.primary,
            child: Padding(
              padding: const EdgeInsets.all(20),
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  const Text(
                    'Fasal Ki Photo Kheenchein / Upload Karein',
                    style: TextStyle(color: Colors.white, fontSize: 17, fontWeight: FontWeight.w600),
                  ),
                  const SizedBox(height: 16),
                  Row(
                    children: [
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => context.push('${AppRoutes.camera}?source=camera'),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black87),
                          icon: const Icon(Icons.camera_alt),
                          label: const Text('Camera'),
                        ),
                      ),
                      const SizedBox(width: 12),
                      Expanded(
                        child: ElevatedButton.icon(
                          onPressed: () => context.push('${AppRoutes.camera}?source=gallery'),
                          style: ElevatedButton.styleFrom(backgroundColor: Colors.white, foregroundColor: Colors.black87),
                          icon: const Icon(Icons.photo_library),
                          label: const Text('Gallery'),
                        ),
                      ),
                    ],
                  ),
                ],
              ),
            ),
          ),
          const SizedBox(height: 16),
          if (weather.loading)
            const Padding(
              padding: EdgeInsets.symmetric(vertical: 12),
              child: Center(child: CircularProgressIndicator()),
            )
          else if (weather.info != null)
            WeatherCard(info: weather.info!)
          else if (weather.locationDenied)
            _ManualCityCard()
          else if (weather.errorMessage != null)
            ErrorView(
              message: weather.errorMessage!,
              onRetry: () => ref.read(weatherControllerProvider.notifier).loadForCurrentLocation(),
            ),
          const SizedBox(height: 12),
          _MenuTile(
            icon: Icons.history,
            title: 'Purane Scan Dekhein',
            onTap: () => context.push(AppRoutes.history),
          ),
          _MenuTile(
            icon: Icons.help_outline,
            title: 'Help / How to Use',
            onTap: () => showDialog(
              context: context,
              builder: (_) => const AlertDialog(
                title: Text('Kaise Use Karein?'),
                content: Text(
                  '1. Camera ya Gallery se fasal ki patti ki photo lein.\n'
                  '2. AI usse analyze karega.\n'
                  '3. Aapko disease, karan, aur solution mil jayega.\n'
                  '4. 🔊 button se result sun bhi sakte hain.',
                ),
              ),
            ),
          ),
          _MenuTile(
            icon: Icons.settings_outlined,
            title: 'Settings',
            onTap: () => context.push(AppRoutes.settings),
          ),
        ],
      ),
    );
  }
}

class _MenuTile extends StatelessWidget {
  final IconData icon;
  final String title;
  final VoidCallback onTap;
  const _MenuTile({required this.icon, required this.title, required this.onTap});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: ListTile(
        leading: Icon(icon),
        title: Text(title),
        trailing: const Icon(Icons.chevron_right),
        onTap: onTap,
      ),
    );
  }
}

class _ManualCityCard extends ConsumerStatefulWidget {
  @override
  ConsumerState<_ManualCityCard> createState() => _ManualCityCardState();
}

class _ManualCityCardState extends ConsumerState<_ManualCityCard> {
  final _controller = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            const Text('Location permission nahi mili. Shehar ka naam likhein:'),
            const SizedBox(height: 8),
            Row(
              children: [
                Expanded(
                  child: TextField(
                    controller: _controller,
                    decoration: const InputDecoration(hintText: 'Jaise: Lucknow'),
                  ),
                ),
                const SizedBox(width: 8),
                IconButton(
                  icon: const Icon(Icons.search),
                  onPressed: () {
                    if (_controller.text.trim().isNotEmpty) {
                      ref.read(weatherControllerProvider.notifier).loadForCity(_controller.text.trim());
                    }
                  },
                ),
              ],
            ),
          ],
        ),
      ),
    );
  }
}
