import 'dart:io';
import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import 'package:image_picker/image_picker.dart';
import 'package:permission_handler/permission_handler.dart';
import '../../core/errors/app_exceptions.dart';
import '../../core/router/app_router.dart';
import '../../core/theme/app_theme.dart';
import '../../providers/scan_provider.dart';
import '../../widgets/error_view.dart';
import '../../widgets/primary_button.dart';

/// Accepts ?source=camera or ?source=gallery via the query string.
class CameraScreen extends ConsumerStatefulWidget {
  const CameraScreen({super.key});

  @override
  ConsumerState<CameraScreen> createState() => _CameraScreenState();
}

class _CameraScreenState extends ConsumerState<CameraScreen> {
  File? _image;
  String? _error;
  bool _picking = false;

  static const int _maxBytes = 12 * 1024 * 1024; // 12 MB safety cap

  Future<void> _pickFromCamera() async {
    setState(() { _picking = true; _error = null; });
    try {
      final status = await Permission.camera.request();
      if (!status.isGranted) throw CameraPermissionDeniedException();
      final picker = ImagePicker();
      final file = await picker.pickImage(source: ImageSource.camera, imageQuality: 80, maxWidth: 1600);
      await _handlePicked(file);
    } on AppException catch (e) {
      setState(() => _error = e.userMessage);
    } catch (_) {
      setState(() => _error = 'Camera open nahi ho paya.');
    } finally {
      setState(() => _picking = false);
    }
  }

  Future<void> _pickFromGallery() async {
    setState(() { _picking = true; _error = null; });
    try {
      final status = await Permission.photos.request();
      if (!status.isGranted && !status.isLimited) throw GalleryPermissionDeniedException();
      final picker = ImagePicker();
      final file = await picker.pickImage(source: ImageSource.gallery, imageQuality: 80, maxWidth: 1600);
      await _handlePicked(file);
    } on AppException catch (e) {
      setState(() => _error = e.userMessage);
    } catch (_) {
      setState(() => _error = 'Gallery open nahi ho payi.');
    } finally {
      setState(() => _picking = false);
    }
  }

  Future<void> _handlePicked(XFile? file) async {
    if (file == null) return;
    final f = File(file.path);
    if (!await f.exists()) throw InvalidImageException();
    final size = await f.length();
    if (size > _maxBytes) throw ImageTooLargeException();
    final ext = file.path.split('.').last.toLowerCase();
    if (!['jpg', 'jpeg', 'png', 'heic'].contains(ext)) throw InvalidImageException();
    setState(() => _image = f);
  }

  void _useThisPhoto() {
    if (_image == null) return;
    ref.read(scanControllerProvider.notifier).runScan(image: _image!);
    context.push(AppRoutes.scanning);
  }

  @override
  void initState() {
    super.initState();
    WidgetsBinding.instance.addPostFrameCallback((_) {
      final uri = GoRouterState.of(context).uri;
      final source = uri.queryParameters['source'];
      if (source == 'camera') {
        _pickFromCamera();
      } else {
        _pickFromGallery();
      }
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Photo Chunein')),
      body: Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          children: [
            if (_picking) const Expanded(child: Center(child: CircularProgressIndicator())),
            if (_error != null)
              Expanded(
                child: ErrorView(
                  message: _error!,
                  onRetry: () => Navigator.of(context).maybePop(),
                ),
              ),
            if (!_picking && _error == null && _image != null) ...[
              Expanded(
                child: ClipRRect(
                  borderRadius: BorderRadius.circular(20),
                  child: Image.file(_image!, fit: BoxFit.cover, width: double.infinity),
                ),
              ),
              const SizedBox(height: 20),
              Row(
                children: [
                  Expanded(
                    child: OutlinedButton.icon(
                      onPressed: () => setState(() => _image = null),
                      icon: const Icon(Icons.replay),
                      label: const Text('Retake'),
                    ),
                  ),
                  const SizedBox(width: 12),
                  Expanded(
                    child: PrimaryButton(
                      label: 'Use This Photo',
                      icon: Icons.check,
                      onPressed: _useThisPhoto,
                      color: AppTheme.primaryGreen,
                    ),
                  ),
                ],
              ),
            ],
            if (!_picking && _error == null && _image == null)
              const Expanded(child: Center(child: Text('Photo select karein...'))),
          ],
        ),
      ),
    );
  }
}
