import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/router/app_router.dart';
import '../../providers/scan_provider.dart';
import '../../widgets/error_view.dart';
import '../../widgets/loading_scan.dart';

class ScanningScreen extends ConsumerWidget {
  const ScanningScreen({super.key});

  String _stageLabel(ScanStage stage) {
    switch (stage) {
      case ScanStage.uploading:
        return 'Image upload ho rahi hai...';
      case ScanStage.detectingLeaf:
        return 'Patti detect ki ja rahi hai...';
      case ScanStage.analyzing:
        return 'Disease analysis chal raha hai...';
      case ScanStage.calculatingConfidence:
        return 'Confidence calculate ho raha hai...';
      case ScanStage.preparingSolution:
        return 'Solution taiyar kiya ja raha hai...';
      default:
        return '';
    }
  }

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final scan = ref.watch(scanControllerProvider);

    ref.listen(scanControllerProvider, (prev, next) {
      if (next.stage == ScanStage.done) {
        context.pushReplacement(AppRoutes.result);
      }
    });

    return Scaffold(
      appBar: AppBar(title: const Text('AI Processing')),
      body: Center(
        child: scan.stage == ScanStage.error
            ? ErrorView(
                message: scan.errorMessage ?? 'Kuch galat ho gaya.',
                onRetry: () {
                  ref.read(scanControllerProvider.notifier).reset();
                  context.pop();
                },
              )
            : scan.image != null
                ? LoadingScanView(image: scan.image!, stageLabel: _stageLabel(scan.stage))
                : const CircularProgressIndicator(),
      ),
    );
  }
}
