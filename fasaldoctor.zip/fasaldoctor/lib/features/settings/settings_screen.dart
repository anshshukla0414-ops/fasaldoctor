import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import '../../providers/settings_provider.dart';

class SettingsScreen extends ConsumerWidget {
  const SettingsScreen({super.key});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final settings = ref.watch(settingsProvider);
    final controller = ref.read(settingsProvider.notifier);

    return Scaffold(
      appBar: AppBar(title: const Text('Settings')),
      body: ListView(
        children: [
          ListTile(
            title: const Text('Language'),
            trailing: DropdownButton<String>(
              value: settings.language,
              items: const [
                DropdownMenuItem(value: 'hi', child: Text('Hindi')),
                DropdownMenuItem(value: 'en', child: Text('English')),
                DropdownMenuItem(value: 'hinglish', child: Text('Hinglish')),
              ],
              onChanged: (v) {
                if (v != null) controller.setLanguage(v);
              },
            ),
          ),
          SwitchListTile(
            title: const Text('Voice (🔊 Result Sunna)'),
            value: settings.voiceEnabled,
            onChanged: controller.setVoiceEnabled,
          ),
          SwitchListTile(
            title: const Text('Notifications'),
            value: settings.notificationsEnabled,
            onChanged: controller.setNotificationsEnabled,
          ),
          ListTile(
            title: const Text('Clear Local Cache'),
            trailing: const Icon(Icons.delete_sweep_outlined),
            onTap: () async {
              final confirmed = await showDialog<bool>(
                context: context,
                builder: (ctx) => AlertDialog(
                  title: const Text('Clear Cache?'),
                  content: const Text('Local settings aur cache clear ho jayenge.'),
                  actions: [
                    TextButton(onPressed: () => Navigator.pop(ctx, false), child: const Text('Cancel')),
                    TextButton(onPressed: () => Navigator.pop(ctx, true), child: const Text('Clear')),
                  ],
                ),
              );
              if (confirmed == true) await controller.clearLocalCache();
            },
          ),
          const Divider(),
          ListTile(
            title: const Text('AI Disclaimer'),
            subtitle: const Text(
              'AI result sirf informational guidance hai. Severe crop damage ya chemical treatment ke liye local agriculture expert/KVK se salah lein.',
            ),
          ),
          const ListTile(
            title: Text('Privacy Policy'),
            subtitle: Text('Aapka data sirf aapke account ke saath surakshit rakha jata hai.'),
          ),
        ],
      ),
    );
  }
}
