import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:go_router/go_router.dart';
import '../../core/router/app_router.dart';
import '../../providers/auth_provider.dart';

class ProfileScreen extends ConsumerWidget {
  final bool embedded;
  const ProfileScreen({super.key, this.embedded = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(firebaseServiceProvider).currentUser;

    final body = ListView(
      padding: const EdgeInsets.all(20),
      children: [
        CircleAvatar(radius: 36, child: Icon(Icons.person, size: 36)),
        const SizedBox(height: 12),
        Text(
          user?.email ?? 'Guest Kisan (Anonymous)',
          textAlign: TextAlign.center,
          style: Theme.of(context).textTheme.titleMedium,
        ),
        Text(
          'UID: ${user?.uid.substring(0, 8) ?? '-'}...',
          textAlign: TextAlign.center,
          style: const TextStyle(color: Colors.grey, fontSize: 12),
        ),
        const SizedBox(height: 24),
        ListTile(
          leading: const Icon(Icons.settings_outlined),
          title: const Text('Settings'),
          trailing: const Icon(Icons.chevron_right),
          onTap: () => context.push(AppRoutes.settings),
        ),
        ListTile(
          leading: const Icon(Icons.info_outline),
          title: const Text('About FasalDoctor'),
          onTap: () => showAboutDialog(
            context: context,
            applicationName: 'FasalDoctor',
            applicationVersion: '1.0.0',
            children: const [Text('AI se Fasal Bachayein — crop disease detection for farmers.')],
          ),
        ),
      ],
    );

    if (embedded) return body;
    return Scaffold(appBar: AppBar(title: const Text('Profile')), body: body);
  }
}
