import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:cached_network_image/cached_network_image.dart';
import 'package:intl/intl.dart';
import '../../models/scan_result.dart';
import '../../providers/auth_provider.dart';
import '../../providers/scan_provider.dart';
import '../../core/theme/app_theme.dart';

class HistoryScreen extends ConsumerWidget {
  final bool embedded;
  const HistoryScreen({super.key, this.embedded = false});

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    final user = ref.watch(firebaseServiceProvider).currentUser;
    final body = user == null
        ? const Center(child: Text('Sign-in ho raha hai...'))
        : Consumer(builder: (context, ref, _) {
            final scansAsync = ref.watch(scansHistoryProvider(user.uid));
            return scansAsync.when(
              data: (scans) {
                if (scans.isEmpty) {
                  return const Center(child: Text('Abhi tak koi scan save nahi hua.'));
                }
                return ListView.builder(
                  padding: const EdgeInsets.all(12),
                  itemCount: scans.length,
                  itemBuilder: (context, i) {
                    final scan = scans[i];
                    return Card(
                      child: ListTile(
                        leading: ClipRRect(
                          borderRadius: BorderRadius.circular(8),
                          child: CachedNetworkImage(
                            imageUrl: scan.imageUrl,
                            width: 56,
                            height: 56,
                            fit: BoxFit.cover,
                            placeholder: (c, u) => const SizedBox(
                              width: 56, height: 56, child: Center(child: CircularProgressIndicator(strokeWidth: 2)),
                            ),
                            errorWidget: (c, u, e) => const Icon(Icons.image_not_supported),
                          ),
                        ),
                        title: Text('${scan.crop} — ${scan.disease}'),
                        subtitle: Text(
                          '${DateFormat('dd MMM yyyy, hh:mm a').format(scan.createdAt)} • '
                          '${(scan.confidence * 100).toStringAsFixed(0)}%',
                        ),
                        trailing: IconButton(
                          icon: const Icon(Icons.delete_outline, color: AppTheme.dangerRed),
                          onPressed: () => _confirmDelete(context, ref, user.uid, scan),
                        ),
                        onTap: () => _showDetail(context, scan.result),
                      ),
                    );
                  },
                );
              },
              loading: () => const Center(child: CircularProgressIndicator()),
              error: (e, st) => const Center(child: Text('History load nahi ho payi.')),
            );
          });

    if (embedded) return body;

    return Scaffold(
      appBar: AppBar(title: const Text('Purane Scan')),
      body: body,
    );
  }

  void _confirmDelete(BuildContext context, WidgetRef ref, String uid, dynamic scan) {
    showDialog(
      context: context,
      builder: (ctx) => AlertDialog(
        title: const Text('Delete Scan?'),
        content: const Text('Kya aap is scan ko history se hatana chahte hain?'),
        actions: [
          TextButton(onPressed: () => Navigator.pop(ctx), child: const Text('Cancel')),
          TextButton(
            onPressed: () {
              ref.read(firebaseServiceProvider).deleteScan(uid, scan.scanId);
              Navigator.pop(ctx);
            },
            child: const Text('Delete', style: TextStyle(color: AppTheme.dangerRed)),
          ),
        ],
      ),
    );
  }

  void _showDetail(BuildContext context, ScanResult result) {
    showModalBottomSheet(
      context: context,
      isScrollControlled: true,
      builder: (ctx) => Padding(
        padding: const EdgeInsets.all(20),
        child: Column(
          mainAxisSize: MainAxisSize.min,
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Text(result.disease, style: Theme.of(ctx).textTheme.titleLarge),
            const SizedBox(height: 8),
            Text(result.description),
            const SizedBox(height: 8),
            Text('Confidence: ${(result.confidence * 100).toStringAsFixed(0)}%'),
          ],
        ),
      ),
    );
  }
}
