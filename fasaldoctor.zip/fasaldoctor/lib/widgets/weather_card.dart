import 'package:flutter/material.dart';
import '../models/weather.dart';

class WeatherCard extends StatelessWidget {
  final WeatherInfo info;
  const WeatherCard({super.key, required this.info});

  @override
  Widget build(BuildContext context) {
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Row(
          children: [
            const Icon(Icons.wb_sunny_outlined, size: 40, color: Colors.orange),
            const SizedBox(width: 12),
            Expanded(
              child: Column(
                crossAxisAlignment: CrossAxisAlignment.start,
                children: [
                  Text(info.locationLabel,
                      style: Theme.of(context).textTheme.titleMedium),
                  Text('${info.condition} • ${info.temperatureC.toStringAsFixed(0)}°C'),
                  Text(
                    'Namee: ${info.humidity}%'
                    '${info.rainChance != null ? ' • Baarish: ${info.rainChance!.toStringAsFixed(0)}%' : ''}'
                    ' • Hawa: ${info.windSpeedKmh.toStringAsFixed(0)} km/h',
                    style: Theme.of(context).textTheme.bodySmall,
                  ),
                ],
              ),
            ),
          ],
        ),
      ),
    );
  }
}
