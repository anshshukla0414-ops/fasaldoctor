import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';
import '../models/scan_result.dart';

class DiseaseCard extends StatelessWidget {
  final ScanResult result;
  const DiseaseCard({super.key, required this.result});

  @override
  Widget build(BuildContext context) {
    final severityColor = AppTheme.severityColor(result.severity);
    return Card(
      child: Padding(
        padding: const EdgeInsets.all(16),
        child: Column(
          crossAxisAlignment: CrossAxisAlignment.start,
          children: [
            Row(
              children: [
                Expanded(
                  child: Text(
                    result.disease,
                    style: Theme.of(context)
                        .textTheme
                        .titleLarge
                        ?.copyWith(fontWeight: FontWeight.bold),
                  ),
                ),
                Container(
                  padding: const EdgeInsets.symmetric(horizontal: 10, vertical: 4),
                  decoration: BoxDecoration(
                    color: severityColor.withValues(alpha: 0.15),
                    borderRadius: BorderRadius.circular(20),
                  ),
                  child: Text(
                    result.severity.toUpperCase(),
                    semanticsLabel: 'Severity: ${result.severity}',
                    style: TextStyle(
                      color: severityColor,
                      fontWeight: FontWeight.w700,
                      fontSize: 12,
                    ),
                  ),
                ),
              ],
            ),
            const SizedBox(height: 4),
            Text('Fasal: ${result.crop}', style: Theme.of(context).textTheme.bodyMedium),
            const SizedBox(height: 8),
            LinearProgressIndicator(
              value: result.confidence.clamp(0.0, 1.0),
              minHeight: 8,
              borderRadius: BorderRadius.circular(6),
              color: severityColor,
              backgroundColor: severityColor.withValues(alpha: 0.15),
            ),
            const SizedBox(height: 4),
            Text('Confidence: ${(result.confidence * 100).toStringAsFixed(0)}%'),
          ],
        ),
      ),
    );
  }
}
