import 'dart:io';
import 'package:flutter/material.dart';
import '../core/theme/app_theme.dart';

class LoadingScanView extends StatefulWidget {
  final File image;
  final String stageLabel;
  const LoadingScanView({super.key, required this.image, required this.stageLabel});

  @override
  State<LoadingScanView> createState() => _LoadingScanViewState();
}

class _LoadingScanViewState extends State<LoadingScanView>
    with SingleTickerProviderStateMixin {
  late final AnimationController _controller;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(vsync: this, duration: const Duration(seconds: 2))
      ..repeat();
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Column(
      mainAxisSize: MainAxisSize.min,
      children: [
        Stack(
          alignment: Alignment.center,
          children: [
            ClipRRect(
              borderRadius: BorderRadius.circular(20),
              child: Image.file(widget.image, height: 260, width: 260, fit: BoxFit.cover),
            ),
            AnimatedBuilder(
              animation: _controller,
              builder: (context, child) {
                return Positioned(
                  top: 260 * _controller.value,
                  child: Container(
                    width: 260,
                    height: 3,
                    color: AppTheme.lightGreen.withValues(alpha: 0.9),
                  ),
                );
              },
            ),
            Container(
              width: 260,
              height: 260,
              decoration: BoxDecoration(
                border: Border.all(color: AppTheme.primaryGreen, width: 2),
                borderRadius: BorderRadius.circular(20),
              ),
            ),
          ],
        ),
        const SizedBox(height: 24),
        const Text('AI Fasal Check Kar Raha Hai...',
            style: TextStyle(fontSize: 18, fontWeight: FontWeight.w600)),
        const SizedBox(height: 8),
        const LinearProgressIndicator(minHeight: 6),
        const SizedBox(height: 12),
        Text(widget.stageLabel, style: const TextStyle(color: Colors.grey)),
      ],
    );
  }
}
