/// Structured result returned by any DiseaseDetectionProvider.
class ScanResult {
  final bool success;
  final String crop;
  final String disease;
  final double confidence; // 0.0 - 1.0
  final String severity; // low | medium | high | unknown
  final String description;
  final List<String> organicSolution;
  final List<String> chemicalSolution;
  final List<String> prevention;
  final String warning;
  final String language; // 'hi' | 'en' | 'hinglish'
  final bool isLowConfidence;

  ScanResult({
    required this.success,
    required this.crop,
    required this.disease,
    required this.confidence,
    required this.severity,
    required this.description,
    required this.organicSolution,
    required this.chemicalSolution,
    required this.prevention,
    required this.warning,
    required this.language,
    this.isLowConfidence = false,
  });

  factory ScanResult.fromJson(Map<String, dynamic> json) {
    return ScanResult(
      success: json['success'] as bool? ?? false,
      crop: json['crop'] as String? ?? 'Unknown',
      disease: json['disease'] as String? ?? 'Unknown',
      confidence: (json['confidence'] as num?)?.toDouble() ?? 0.0,
      severity: json['severity'] as String? ?? 'unknown',
      description: json['description'] as String? ?? '',
      organicSolution: (json['organic_solution'] as List?)?.cast<String>() ?? [],
      chemicalSolution: (json['chemical_solution'] as List?)?.cast<String>() ?? [],
      prevention: (json['prevention'] as List?)?.cast<String>() ?? [],
      warning: json['warning'] as String? ?? '',
      language: json['language'] as String? ?? 'hi',
      isLowConfidence: (json['confidence'] as num? ?? 1.0) < 0.5,
    );
  }

  Map<String, dynamic> toJson() => {
        'success': success,
        'crop': crop,
        'disease': disease,
        'confidence': confidence,
        'severity': severity,
        'description': description,
        'organic_solution': organicSolution,
        'chemical_solution': chemicalSolution,
        'prevention': prevention,
        'warning': warning,
        'language': language,
      };

  factory ScanResult.lowConfidenceFallback() => ScanResult(
        success: true,
        crop: 'Unknown',
        disease: 'Not determined',
        confidence: 0.0,
        severity: 'unknown',
        description:
            'Image se reliable diagnosis nahi ho paya. Photo clear aur achhi lighting mein leke dobara try karein.',
        organicSolution: const [],
        chemicalSolution: const [],
        prevention: const [
          'Patti ko close-up aur focus mein photo karein',
          'Din ki roshni mein photo lein',
          'Crop type select karke dobara try karein',
        ],
        warning:
            'AI result sirf informational guidance hai. Severe crop damage ya chemical treatment ke liye local agriculture expert/KVK se salah lein.',
        language: 'hi',
        isLowConfidence: true,
      );
}

/// A saved scan record (users/{uid}/scans/{scanId}).
class Scan {
  final String scanId;
  final String userId;
  final String imageUrl;
  final String crop;
  final String disease;
  final double confidence;
  final String severity;
  final ScanResult result;
  final DateTime createdAt;
  final String? location;
  final String language;

  Scan({
    required this.scanId,
    required this.userId,
    required this.imageUrl,
    required this.crop,
    required this.disease,
    required this.confidence,
    required this.severity,
    required this.result,
    required this.createdAt,
    this.location,
    required this.language,
  });

  Map<String, dynamic> toFirestore() => {
        'scanId': scanId,
        'userId': userId,
        'imageUrl': imageUrl,
        'crop': crop,
        'disease': disease,
        'confidence': confidence,
        'severity': severity,
        'organicSolution': result.organicSolution,
        'chemicalSolution': result.chemicalSolution,
        'prevention': result.prevention,
        'description': result.description,
        'warning': result.warning,
        'createdAt': createdAt.toIso8601String(),
        'location': location,
        'language': language,
      };

  factory Scan.fromFirestore(Map<String, dynamic> doc, String id) {
    return Scan(
      scanId: id,
      userId: doc['userId'] as String? ?? '',
      imageUrl: doc['imageUrl'] as String? ?? '',
      crop: doc['crop'] as String? ?? 'Unknown',
      disease: doc['disease'] as String? ?? 'Unknown',
      confidence: (doc['confidence'] as num?)?.toDouble() ?? 0.0,
      severity: doc['severity'] as String? ?? 'unknown',
      result: ScanResult(
        success: true,
        crop: doc['crop'] as String? ?? 'Unknown',
        disease: doc['disease'] as String? ?? 'Unknown',
        confidence: (doc['confidence'] as num?)?.toDouble() ?? 0.0,
        severity: doc['severity'] as String? ?? 'unknown',
        description: doc['description'] as String? ?? '',
        organicSolution: (doc['organicSolution'] as List?)?.cast<String>() ?? [],
        chemicalSolution: (doc['chemicalSolution'] as List?)?.cast<String>() ?? [],
        prevention: (doc['prevention'] as List?)?.cast<String>() ?? [],
        warning: doc['warning'] as String? ?? '',
        language: doc['language'] as String? ?? 'hi',
      ),
      createdAt: DateTime.tryParse(doc['createdAt'] as String? ?? '') ?? DateTime.now(),
      location: doc['location'] as String?,
      language: doc['language'] as String? ?? 'hi',
    );
  }
}
