class UserProfile {
  final String uid;
  final String? displayName;
  final String? email;
  final String language; // 'hi' | 'en' | 'hinglish'
  final bool voiceEnabled;
  final bool notificationsEnabled;
  final DateTime createdAt;

  UserProfile({
    required this.uid,
    this.displayName,
    this.email,
    this.language = 'hi',
    this.voiceEnabled = true,
    this.notificationsEnabled = true,
    required this.createdAt,
  });

  Map<String, dynamic> toFirestore() => {
        'displayName': displayName,
        'email': email,
        'language': language,
        'voiceEnabled': voiceEnabled,
        'notificationsEnabled': notificationsEnabled,
        'createdAt': createdAt.toIso8601String(),
      };

  factory UserProfile.fromFirestore(Map<String, dynamic> doc, String uid) {
    return UserProfile(
      uid: uid,
      displayName: doc['displayName'] as String?,
      email: doc['email'] as String?,
      language: doc['language'] as String? ?? 'hi',
      voiceEnabled: doc['voiceEnabled'] as bool? ?? true,
      notificationsEnabled: doc['notificationsEnabled'] as bool? ?? true,
      createdAt: DateTime.tryParse(doc['createdAt'] as String? ?? '') ?? DateTime.now(),
    );
  }

  UserProfile copyWith({
    String? language,
    bool? voiceEnabled,
    bool? notificationsEnabled,
  }) {
    return UserProfile(
      uid: uid,
      displayName: displayName,
      email: email,
      language: language ?? this.language,
      voiceEnabled: voiceEnabled ?? this.voiceEnabled,
      notificationsEnabled: notificationsEnabled ?? this.notificationsEnabled,
      createdAt: createdAt,
    );
  }
}
