class WeatherInfo {
  final double temperatureC;
  final String condition;
  final int humidity;
  final double? rainChance;
  final double windSpeedKmh;
  final String locationLabel;

  WeatherInfo({
    required this.temperatureC,
    required this.condition,
    required this.humidity,
    this.rainChance,
    required this.windSpeedKmh,
    required this.locationLabel,
  });

  factory WeatherInfo.fromOpenMeteo(Map<String, dynamic> json, String locationLabel) {
    final current = json['current'] as Map<String, dynamic>? ?? {};
    return WeatherInfo(
      temperatureC: (current['temperature_2m'] as num?)?.toDouble() ?? 0.0,
      condition: _codeToCondition(current['weather_code'] as int? ?? 0),
      humidity: (current['relative_humidity_2m'] as num?)?.toInt() ?? 0,
      rainChance: (current['precipitation_probability'] as num?)?.toDouble(),
      windSpeedKmh: (current['wind_speed_10m'] as num?)?.toDouble() ?? 0.0,
      locationLabel: locationLabel,
    );
  }

  static String _codeToCondition(int code) {
    if (code == 0) return 'Saaf Aasman';
    if (code <= 3) return 'Halka Baadal';
    if (code >= 51 && code <= 67) return 'Baarish';
    if (code >= 71 && code <= 77) return 'Baraf';
    if (code >= 80 && code <= 82) return 'Tez Baarish';
    if (code >= 95) return 'Aandhi/Toofan';
    return 'Mausam';
  }
}
