import 'dart:io';
import 'package:flutter_test/flutter_test.dart';
import 'package:fasaldoctor/services/ai_service.dart';

void main() {
  group('MockDiseaseDetectionProvider', () {
    test('returns a valid ScanResult without any network/config', () async {
      final provider = MockDiseaseDetectionProvider();
      final tempFile = File('${Directory.systemTemp.path}/test_leaf.jpg')
        ..writeAsBytesSync(List<int>.filled(100, 1));

      final result = await provider.detectDisease(image: tempFile, cropType: 'Cotton');

      expect(result.success, true);
      expect(result.crop.isNotEmpty, true);
      expect(result.confidence, inInclusiveRange(0.0, 1.0));

      tempFile.deleteSync();
    });
  });
}
