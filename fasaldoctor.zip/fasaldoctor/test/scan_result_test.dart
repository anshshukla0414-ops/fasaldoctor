import 'package:flutter_test/flutter_test.dart';
import 'package:fasaldoctor/models/scan_result.dart';

void main() {
  group('ScanResult', () {
    test('fromJson parses a full backend response correctly', () {
      final json = {
        'success': true,
        'crop': 'Cotton',
        'disease': 'Leaf Spot',
        'confidence': 0.91,
        'severity': 'medium',
        'description': 'desc',
        'organic_solution': ['a', 'b'],
        'chemical_solution': ['c'],
        'prevention': ['d'],
        'warning': 'warn',
        'language': 'hi',
      };
      final result = ScanResult.fromJson(json);
      expect(result.crop, 'Cotton');
      expect(result.disease, 'Leaf Spot');
      expect(result.confidence, 0.91);
      expect(result.isLowConfidence, false);
    });

    test('low confidence is flagged correctly below threshold', () {
      final json = {'success': true, 'confidence': 0.32};
      final result = ScanResult.fromJson(json);
      expect(result.isLowConfidence, true);
    });

    test('lowConfidenceFallback never claims a definitive diagnosis', () {
      final fallback = ScanResult.lowConfidenceFallback();
      expect(fallback.confidence, 0.0);
      expect(fallback.isLowConfidence, true);
      expect(fallback.disease, 'Not determined');
    });
  });
}
